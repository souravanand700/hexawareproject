import { useState } from 'react'
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ListAllProduct from './components/ListAllProducts'
import AddProducts from './components/AddProducts'
import CartList from './components/CartList'
import Billing from './components/Billing'

function ErrorBoundary({ children }) {
    try {
        return children;
    } catch (error) {
        return <h2>Something went wrong: {error.message}</h2>;
    }
}

function App() {
    return (
        <>
            <div>
                <BrowserRouter>
                    <Routes>
                        <Route path="/" element={<ListAllProduct />} />
                        <Route path="/add-product" element={<AddProducts />} />
                        <Route path="/cart" element={<CartList />} />
                        <Route path="/billing" element={
                            <ErrorBoundary>
                                <Billing />
                            </ErrorBoundary>
                        } />
                    </Routes>
                </BrowserRouter>
            </div>
        </>
    )
}

export default App;
