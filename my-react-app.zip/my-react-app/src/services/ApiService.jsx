import axios from "axios";

const API_BASE_URL = "http://127.0.0.1:8000";

const ApiService = {
    // Fetch all products
    getAllProducts: () => axios.get(`${API_BASE_URL}/`),

    // Create a new product
    createProduct: (product) => {
        console.log("Sending product:", product);
        return axios.post(`${API_BASE_URL}/product`, product, {
            headers: { "Content-Type": "application/json" }, 
        });
    },

    // Update an existing product
    updateProduct: (product, productId) => {
        console.log("Updating product:", product);
        return axios.put(`${API_BASE_URL}/product/${productId}`, product, {
            headers: { "Content-Type": "application/json" }, 
        });
    },

    // Fetch a single product by ID
    getProductById: (productId) => axios.get(`${API_BASE_URL}/products/${productId}`),

    // Add an item to the cart
    addToCart(productId) {
        return axios.post(`${API_BASE_URL}/cart/${productId}`, {
            headers: { "Content-Type": "application/json" }, 
        });
    },
    

    // Get all cart items
    getCartItems: () => axios.get(`${API_BASE_URL}/cart`),

    // Decrement quantity of item in cart
    decrementCartItem: (cartId) => axios.put(`${API_BASE_URL}/cart/${cartId}/decrement`),


    // Delete a product
    deleteProduct: (id) => axios.delete(`${API_BASE_URL}/product/${id}`),

    // Restock a product
    restockProduct: (productId) => {
        return axios.put(`${API_BASE_URL}/products/${productId}/restock`);
    },
    
    // Clear cart items
    purchaseItems: () => {
        return axios.delete(`${API_BASE_URL}/cart/clear`);
    }
};

export default ApiService;
