import { Link } from 'react-router-dom';
import ApiService from '../services/ApiService';
import React, { useEffect, useState } from "react";

export default function ListAllProduct() {
    const [productArray, setProductArray] = useState([]);

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const response = await ApiService.getAllProducts();
            setProductArray(response.data);
        } catch (error) {
            console.error("Error fetching products:", error);
        }
    };

    const deleteProduct = async (productId) => {
        try {
            await ApiService.deleteProduct(productId);
            setProductArray(productArray.filter(product => product.Product_id !== productId));
        } catch (error) {
            console.error("Error deleting product:", error);
        }
    };

    const addToCart = async (productId) => {
        try {
            await ApiService.addToCart(productId);
            console.log(`Product ${productId} added to cart.`);
            fetchProducts(); // Refresh product list after adding to cart
        } catch (error) {
            console.error("Error adding to cart:", error.response?.data || error.message);
        }
    };

    const restockProduct = async (productId) => {
        try {
            await ApiService.restockProduct(productId);
            console.log(`Product ${productId} restocked.`);
            fetchProducts(); // Refresh product list after restocking
        } catch (error) {
            console.error("Error restocking product:", error.response?.data || error.message);
        }
    };

    return (
        <div className='container'>
            {console.log("List Product got rendered")}
            <h2 className='text-center mt-5'>Product Details</h2>

            <div className='d-flex justify-content-center my-3'>
                <Link to="/add-product" className='btn btn-primary btn-md'>Add Product</Link>
            </div>

            <div className='d-flex justify-content-center my-3'>
                <Link to="/cart" className='btn btn-primary btn-md'>Show Cart</Link>
            </div>

            <table className='p-5 m-5 table table-bordered border-secondary table-striped table-hover'>
                <thead>
                    <tr>
                        <th>Product Id</th>
                        <th>Product Name</th>
                        <th>Product Category</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>
                        <th>Delete</th>
                        <th>Add to Cart</th>
                        <th>Restock</th>
                    </tr>
                </thead>
                <tbody>
                    {productArray.map((product) => (
                        <tr key={product.Product_id}>
                            <td>{product.Product_id}</td>
                            <td>{product.Product_name}</td>
                            <td>{product.Product_category}</td>
                            <td>{product.price}</td>
                            <td>{product.Product_quantity}</td>
                            <td>
                                <button 
                                    className='btn btn-danger btn-md'
                                    onClick={() => deleteProduct(product.Product_id)}
                                >
                                    Delete
                                </button>
                            </td>
                            <td>
                                <button 
                                    className='btn btn-primary btn-md' 
                                    onClick={() => addToCart(product.Product_id)} 
                                >
                                    Add to Cart
                                </button>
                            </td>
                            <td>
                                <button 
                                    className='btn btn-success btn-md' 
                                    onClick={() => restockProduct(product.Product_id)} 
                                >
                                    Restock
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
