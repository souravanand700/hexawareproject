import React, { useEffect, useState } from "react";
import ApiService from "../services/ApiService";
import { Link } from "react-router-dom";

export default function CartList() {
    const [cartItems, setCartItems] = useState([]);

    useEffect(() => {
        fetchCartItems();
    }, []);

    const fetchCartItems = () => {
        ApiService.getCartItems()
            .then(response => {
                setCartItems(response.data);
            })
            .catch(error => {
                console.error("Error fetching cart items:", error);
            });
    };

    const handleRemoveFromCart = (cartId) => {
        ApiService.decrementCartItem(cartId)
            .then(() => {
                fetchCartItems(); // Refresh cart after update
            })
            .catch(error => {
                console.error("Error decrementing cart item:", error);
            });
    };
    

    return (
        <div className="container">
            <h2 className="text-center mt-5">Shopping Cart</h2>
            <div className='d-flex justify-content-center my-3'>
                <Link to="/" className='btn btn-primary btn-md'>Back to Product List</Link>
            </div>
            <div className='d-flex justify-content-center my-3'>
                <Link to="/billing" className='btn btn-primary btn-md'>Purchase/Billing</Link>
            </div>
            {cartItems.length === 0 ? (
                <p>Your cart is empty.</p>) : (
                <table className='p-5 m-5 table table-bordered border-secondary table-striped table-hover'>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {cartItems.map(item => (
                            <tr key={item.cart_id}>
                                <td>{item.cart_id}</td>
                                <td>{item.product_name}</td>
                                <td>{item.category}</td>
                                <td>${item.price}</td>
                                <td>{item.quantity}</td>
                                <td>
                                    <button className="btn btn-danger btn-md" onClick={() => handleRemoveFromCart(item.cart_id)}>Remove</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}
