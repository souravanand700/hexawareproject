import React, { useState } from "react";
import ApiService from "../services/ApiService";
import { useNavigate } from "react-router-dom";

export default function AddProduct() {
    const [productId, setProductId] = useState("");
    const [product, setProduct] = useState({
        name: "",
        category: "",
        price: "",
        quantity: ""
    });

    const navigate = useNavigate();

    // Handle input change
    const handleChange = (e) => {
        setProduct({ ...product, [e.target.name]: e.target.value });
    };

    // Handle productId input change and fetch product details
    const handleProductIdChange = async (e) => {
    const id = e.target.value;
    setProductId(id);

    if (id) {
        try {
            const response = await ApiService.getProductById(id);
            console.log("Fetched product data:", response.data);

            if (response.data) {
                setProduct({
                    name: response.data.Product_name,
                    category: response.data.Product_category,
                    price: response.data.price,
                    quantity: response.data.Product_quantity,
                });
            } else {
                setProduct({ name: "", category: "", price: "", quantity: "" }); 
            }
        } catch (error) {
            console.error("Error fetching product:", error);
            setProduct({ name: "", category: "", price: "", quantity: "" });
        }
    } else {
        setProduct({ name: "", category: "", price: "", quantity: "" });
    }
};


    // Save or update product
    const saveOrUpdateProduct = () => {
        if (productId) {
            console.log("Updating product:", product);
            ApiService.updateProduct(product, productId)
                .then((response) => {
                    console.log("Product updated successfully:", response.data);
                    navigate("/");
                })
                .catch((error) => {
                    console.error("Error in updateProduct() API:", error);
                });
        } else {
            console.log("Creating new product:", product);
            ApiService.createProduct(product)
                .then((response) => {
                    console.log("Product created successfully:", response.data);
                    navigate("/");
                })
                .catch((error) => {
                    console.error("Error in createProduct() API:", error);
                });
        }
    };

    return (
        <div>
            <h2>{productId ? "Update Product" : "Add Product"}</h2>
            
            {/* Input field to enter product ID */}
            <input 
                type="number" 
                name="productId" 
                placeholder="Enter Product ID to update" 
                onChange={handleProductIdChange} 
                value={productId} 
            />
            
            <input 
                type="text" 
                name="name" 
                placeholder="Name" 
                onChange={handleChange} 
                value={product.name} 
            />
            
            <input 
                type="text" 
                name="category" 
                placeholder="Category" 
                onChange={handleChange} 
                value={product.category} 
            />
            
            <input 
                type="number" 
                name="price" 
                placeholder="Price" 
                onChange={handleChange} 
                value={product.price} 
            />
            
            <input 
                type="number" 
                name="quantity" 
                placeholder="Quantity" 
                onChange={handleChange} 
                value={product.quantity} 
            />
            
            <button onClick={saveOrUpdateProduct}>
                {productId ? "Update Product" : "Save Product"}
            </button>
        </div>
    );
}

