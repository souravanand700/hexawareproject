import React, { useEffect, useState } from "react";
import ApiService from "../services/ApiService";
import { Link } from "react-router-dom";

export default function BillingCart() {
    const [cartItems, setCartItems] = useState([]);
    const [totalAmount, setTotalAmount] = useState(0);

    useEffect(() => {
        fetchCartItems();
    }, []);

    const fetchCartItems = () => {
        ApiService.getCartItems()
            .then(response => {
                setCartItems(response.data);
                calculateTotal(response.data);
            })
            .catch(error => {
                console.error("Error fetching cart items:", error);
            });
    };

    const calculateTotal = (items) => {
        const total = items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
        setTotalAmount(total);
    };

    const handlePurchase = async () => {
        try {
            await ApiService.purchaseItems();
            setCartItems([]); 
            setTotalAmount(0); // Reset total amount
            alert("Purchase successful! Cart has been cleared.");
        } catch (error) {
            console.error("Error completing purchase:", error);
        }
    };

    return (
        <div className="container">
            <h2 className="text-center mt-5">Billing Summary</h2>
            <div className='d-flex justify-content-center my-3'>
                <Link to="/" className='btn btn-primary btn-md'>Back to product list</Link>
            </div>
            <table className="p-5 m-5 table table-bordered border-secondary table-striped table-hover">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {cartItems.map(item => (
                        <tr key={item.cart_id}>
                            <td>{item.product_name}</td>
                            <td>{item.quantity}</td>
                            <td>${item.price}</td>
                            <td>${(item.quantity * item.price).toFixed(2)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <h3 className="text-center mt-5">Total Amount: ${totalAmount.toFixed(2)}</h3>
            <div className="text-center">
                <button className="btn btn-success" onClick={handlePurchase}>
                    Purchase
                </button>
            </div>
        </div>
    );
}
